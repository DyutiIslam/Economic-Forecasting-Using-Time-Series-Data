# Economic-Data-Analysis-Using-Machine-Learning-
This repository contains a comprehensive project focused on predicting the Consumer Price Index (CPI) and Unemployment Rate (UNRATE) using advanced machine learning techniques. The dataset comprises historical CPI and unemployment data, with engineered features to capture trends, seasonality, and lags in time-series data. 
